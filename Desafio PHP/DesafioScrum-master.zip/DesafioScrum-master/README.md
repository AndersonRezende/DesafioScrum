# DesafioScrum
Aplicativo que cadastre itens para a venda e esse itens podem ser comprados por N pessoas. Ao final do estoque do item o sistema deverá mostrar a melhor rota de entrega do item para a equipe de logística.
